import time
import random
import sys
import os

def glitch_effect(text):
    glitched = ''
    for char in text:
        glitched += char
        sys.stdout.write(glitched + '\r')
        sys.stdout.flush()
        time.sleep(0.05)
    print(text)

def haunted_loop():
    messages = [
        "They are watching...",
        "You shouldn't have run this.",
        "System breach detected.",
        "Files...corrupting...",
        "Welcome to the void.",
        "ERROR 666: UNKNOWN ENTITY FOUND"
    ]
    for _ in range(13):
        msg = random.choice(messages)
        glitch_effect(msg)
        time.sleep(random.uniform(0.3, 1.0))

def fake_corruption():
    for i in range(1, 101, random.randint(5, 20)):
        print
        time.sleep(0.1)
    print("Corruption complete. Goodbye.")

def main():
    glitch_effect("Initializing...")
    time.sleep(1)
    haunted_loop()
    fake_corruption()

if __name__ == "__main__":
    main()